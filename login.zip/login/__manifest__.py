{
    "name"      : "Login Theme",
    "summary"   : """ Module for modified default odoo login page """,
    "version"       : "12.0",
    "license"       : "LGPL-3",
    "depends"       : ["base"],
    "author"        : "saber",
    "category"      : "Themes",
    "support"       : "saber@gmail.com",
    "depends"       : ["base"],
    "data"          : ["view/login.xml"],

    'installable': True,
    'auto_install': False,
    'application': True,

}
