{
    "name"      : "Login Theme",
    "summary"   : """ Module for modified default odoo login page odoo 12""",
    "version"       : "12.0",
    "license"       : "LGPL-3",
    "depends"       : ["base"],
    "author"        : "saber",
    "category"      : "Themes",
    "support"       : "sma.genius@hotmail.com""01111704545",
    "depends"       : ["base"],
    "data"          : ["view/login.xml"],

    'installable': True,
    'auto_install': False,
    'application': True,

}
